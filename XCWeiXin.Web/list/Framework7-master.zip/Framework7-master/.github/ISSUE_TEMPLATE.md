This is a (multiple allowed):
* [x] bug
* [ ] enhancement
* [ ] feature-discussion (RFC)

* Framework7 Version: EXACT RELEASE VERSION OR COMMIT HASH, HERE.
* Platform and Target: PLATFORM CLIENT YOU ARE TARGETING SUCH AS CORDOVA, IOS, ANDROID, ETC.
* Live Link or JSFiddle/Codepen: PREFERABLY _(IF YOU WANT YOUR ISSUE TO BE RESOLVED ASAP)_. You can start from forking one of the templates: iOS [JSFiddle](https://jsfiddle.net/s2n1p730/)/[Codepen](https://codepen.io/nolimits4web/pen/WRRWwN), Material [JSFiddle](https://jsfiddle.net/0ogxxcvt/)/[Codepen](https://codepen.io/nolimits4web/pen/pEPPPK)

### What you did
EXPLAIN WHAT YOU DID, PREFERABLY WITH CODE EXAMPLES, HERE.

### Expected Behavior
EXPLAIN WHAT IS TO BE EXPECTED, HERE.

### Actual Behavior
EXPLAIN WHAT IS ACTUALLY HAPPENING, HERE.

P.S. Remember, an issue is not the place to ask questions. You can use [Stack Overflow](http://stackoverflow.com/questions/tagged/framework7)
for that or join the #framework7 channel on irc.freenode.net, where we will be more
than happy to help answer your questions.

Before you open an issue, please check if a similar issue already exists or has been closed before.
