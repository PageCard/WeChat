    //Return instance
    return app;
};

// Save Dom7
Framework7.$ = window.Dom7;
